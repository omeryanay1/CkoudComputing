from flask import Flask, request
from flask_restful import Resource, Api
import requests
import LoansCollection
from bson.objectid import ObjectId


loanCol = LoansCollection.LoansCollection()

BOOKS_SERVICE_URL = 'http://bookapi:8000/books'

class Loans(Resource):
    """
    Loans class that handles /loans
    """
    def post(self):
        try:
            args = request.get_json()
            memberName = args["memberName"]
            ISBN = args["ISBN"]
            loanDate = args["loanDate"]
            if not memberName or not ISBN or not loanDate:
                return {"error": "Unprocessable Content"}, 422
        except KeyError:
            return {"error": "Unprocessable Content"}, 422
        except:
            return {"error": "Unsupported media type"}, 415

        try:
            response = requests.get(f'{BOOKS_SERVICE_URL}?ISBN={ISBN}')
            if response.status_code == 404: 
                return {"error": "Book not found"}, 422
            elif response.status_code != 200:
                return {"error": "Books Service unavailable"}, 422
            if not response.json():
                return {"error": "Book not found"}, 422
            book_data = response.json()[0]  
            if book_data == []: 
                return {"error": "Book not found"}, 422
        except requests.exceptions.RequestException as e:
            return {"error": f"Internal Server Error: Unable to connect to Books Service - {str(e)}"}, 500

        existing_loans = loanCol.retrieveLoansByParameter({"ISBN": ISBN})
        if existing_loans:
            return {"error": "Book already on loan"}, 422

        member_loans = loanCol.retrieveLoansByParameter({"memberName": memberName})
        if len(member_loans) >= 2:
            return {"error": "Member has too many loans"}, 422

        loan = {
            "memberName": memberName,
            "ISBN": ISBN,
            "title": book_data["title"],
            "bookID": book_data["id"],
            "loanDate": loanDate
        }

        loanID = loanCol.insertLoan(loan)
        if not loanID:
            return {"error": "Unable to create loan"}, 422

        return {"loanID": loanID}, 201
    
    def get(self):
        args = request.args
        if args == {}:
            return loanCol.retrieveAllLoans(), 200
        else:
            return loanCol.retrieveLoansByParameter(args), 200

class LoanId(Resource):
    """
    LoanId class that handles /loan/{id}
    """
    def get(self, loan_id):
        success, loan = loanCol.findLoan(loan_id)
        if success:
            return loan, 200
        else:
            return {"error": "Not Found"}, 404
    
    def delete(self, loan_id):
        success = loanCol.deleteLoan((loan_id))
        if success:
            return {"loanID": loan_id}, 200
        else:
            return {"error": "Not Found"}, 404

app = Flask(__name__)
api = Api(app)

if __name__ == "__main__":
    api.add_resource(Loans, '/loans')
    api.add_resource(LoanId, '/loans/<string:loan_id>')
    app.run(host='0.0.0.0', port=8001, debug=True)
